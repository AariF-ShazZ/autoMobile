import React, { useEffect, useState } from 'react'
import {
  FormControl,
  FormLabel,
  FormErrorMessage,
  FormHelperText,
  Box,
  Checkbox,
  CheckboxGroup,
  VStack,
  Heading
} from '@chakra-ui/react'
import { useSearchParams } from 'react-router-dom'
const FilterCom = () => {
  const [searchParams, setSearchParams] = useSearchParams()
  const initialCategory = searchParams.getAll("category")
  // console.log("initialCategory =>", initialCategory);
  const [category, setCategory] = useState(initialCategory || [])

  const handleFilterCheckbox = (e) => {
    // console.log(e.target.value);
    const newCategories = [...category]
    if (newCategories.includes(e.target.value)) {
      newCategories.splice(newCategories.indexOf(e.target.value), 1)
    } else {
      newCategories.push(e.target.value)
    }
    setCategory(newCategories)
  }

  // console.log("category",category);
  useEffect(() => {
    let params = {}
    params.category = category
    setSearchParams(params)
  }, [category, setSearchParams])
  return (
    <>
      <Box w={"100%"} h={"400px"} bg={"gray"}>
        <Box>
          <Heading as='legend'>
            Types
          </Heading>
          <CheckboxGroup defaultValue='Itachi'>
            <VStack spacing='24px'>
              <div>
                <input
                  type="checkbox"
                  value={"MEN"}
                  checked={category.includes("MEN")}
                  onChange={handleFilterCheckbox} />
                <label htmlFor="">MEN</label>
              </div>
              <div>
                <input
                  type="checkbox"
                  value={"WOMEN"}
                  checked={category.includes("WOMEN")}
                  onChange={handleFilterCheckbox} />
                <label htmlFor="">WOMEN</label>
              </div>
              <div>
                <input
                  type="checkbox"
                  value={"KIDS"}
                  checked={category.includes("KIDS")}
                  onChange={handleFilterCheckbox} />
                <label htmlFor="">KIDS</label>
              </div>
            </VStack>
          </CheckboxGroup>
        </Box>
      </Box>
    </>
  )
}

export default FilterCom