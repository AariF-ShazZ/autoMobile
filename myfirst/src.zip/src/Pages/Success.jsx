import React from 'react'

const Success = () => {
  return (
    <div>Success</div>
  )
}

export default Success